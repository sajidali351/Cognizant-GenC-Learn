export interface Skill{
    id:number;
    name:string;
}