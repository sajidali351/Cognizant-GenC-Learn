import { Employee } from './employee';

let employee1 = {id:1, name:'John', salary:25000, permanent:true, department:{id:101, name:'Payroll'}, skill:[{id:1001, name:'HTML'},{id:1002, name:'CSS'}]};


let employeeDetails = (type:Employee) : void => {
    console.log('id: ' + type.id);
    console.log('name: ' + type.name);
    console.log('salary: ' + type.salary);
    console.log('permanet: ' + type.permanent);
    console.log('department id: ' + type.department.id);
    console.log('department name: ' + type.department.name);
    for(let i = 0; i < type.skill.length; i++) { 
        console.log("skill[" + i + "]: " + type.skill[i].id + " ," + type.skill[i].name);
     }
    
}

let emp = employeeDetails(employee1);
console.log(emp);


