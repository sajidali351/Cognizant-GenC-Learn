"use strict";
exports.__esModule = true;
exports.EmployeeTest = void 0;
var EmployeeTest = /** @class */ (function () {
    function EmployeeTest(id, name, salary, permanent, department) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.permanent = permanent;
        this.department = department;
    }
    EmployeeTest.prototype.display = function () {
        console.log("id: " + this.id);
        console.log("name: " + this.name);
        console.log("salary: " + this.salary);
        console.log("permanent: " + this.permanent);
        console.log("department id: " + this.department.id);
        console.log("department name: " + this.department.name);
    };
    return EmployeeTest;
}());
exports.EmployeeTest = EmployeeTest;
var dept = { id: 101, name: "HR" };
var emp = new EmployeeTest(1, "jhon", 10000, true, dept);
emp.display();
